const request = require('request');

const options = {
    url: 'https://ifconfig.co/json',
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Accept-Charset': 'utf-8',
        'User-Agent': 'salawu'
    }
};

exports.ifconfig = (req, res) => {
  request(options, function (error, response, body) {
    console.log('error:', error);
    console.log('statusCode:', response.statusCode);
    console.log('body:', body);
    res.send(body);
  });
};
